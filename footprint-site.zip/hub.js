'use strict';
/* Feature hub: pressing a tile or an arrow spins the phone in 3D and shows that feature on its screen. */
(() => {
  const phone = document.querySelector('#phone3d');
  if (!phone) return;
  const tiles = [...document.querySelectorAll('button.hub-tile')];
  const frames = new Map([...phone.querySelectorAll('iframe')].map(frame => [frame.dataset.feature, frame]));
  const ORDER = [...frames.keys()];
  const nameLabel = document.querySelector('#hub-name');
  const target = location.origin === 'null' ? '*' : location.origin;
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const SPIN = 1300;
  let spin, swapTimer, current = ORDER[0];

  function post(frame, message) { try { frame.contentWindow?.postMessage(message, target); } catch (error) {} }
  function ensureLoaded(frame) { if (!frame.getAttribute('src') && frame.dataset.src) frame.src = frame.dataset.src; }
  function show(feature) {
    for (const [name, frame] of frames) {
      const active = name === feature;
      if (active) ensureLoaded(frame);
      frame.hidden = !active;
      post(frame, {type:'footprint-demo-visibility', active});
    }
  }
  function mark(feature) {
    tiles.forEach(tile => tile.setAttribute('aria-pressed', String(tile.dataset.feature === feature)));
    const main = tiles.find(tile => tile.dataset.key === feature);
    if (nameLabel && main) nameLabel.textContent = main.dataset.name;
  }
  function select(feature) {
    if (feature === current || !frames.has(feature)) return;
    current = feature;
    mark(feature);
    ensureLoaded(frames.get(feature));
    clearTimeout(swapTimer);
    if (reducedMotion.matches) { show(feature); return; }
    // If the phone is off screen (small screens), bring it into view before it turns.
    const box = phone.getBoundingClientRect();
    const hidden = box.top < 0 || box.bottom > window.innerHeight;
    if (hidden) phone.scrollIntoView({behavior:'smooth', block:'center'});
    const delay = hidden ? 450 : 0;
    setTimeout(() => {
      // A full 3D turn: the phone leans back and pulls away as its edge and back come round.
      spin?.cancel();
      spin = phone.animate([
        {transform:'translateZ(0) rotateX(0deg) rotateY(0deg)'},
        {transform:'translateZ(-140px) rotateX(12deg) rotateY(100deg)', offset:.3},
        {transform:'translateZ(-180px) rotateX(10deg) rotateY(180deg)', offset:.5},
        {transform:'translateZ(-140px) rotateX(6deg) rotateY(262deg)', offset:.72},
        {transform:'translateZ(0) rotateX(0deg) rotateY(360deg)'}
      ], {duration:SPIN, easing:'cubic-bezier(.45,.05,.3,1)'});
    }, delay);
    // Swap the screen while the back of the phone is facing the viewer.
    swapTimer = setTimeout(() => show(feature), delay + SPIN / 2);
  }
  const step = direction => select(ORDER[(ORDER.indexOf(current) + direction + ORDER.length) % ORDER.length]);
  tiles.forEach(tile => tile.addEventListener('click', () => select(tile.dataset.feature)));
  document.querySelector('#hub-prev')?.addEventListener('click', () => step(-1));
  document.querySelector('#hub-next')?.addEventListener('click', () => step(1));
  mark(current);
  // Load the other previews quietly, one at a time, so a spin never lands on a blank screen.
  window.addEventListener('load', () => [...frames.values()].forEach((frame, index) => setTimeout(() => ensureLoaded(frame), 1200 + index * 350)));
})();
