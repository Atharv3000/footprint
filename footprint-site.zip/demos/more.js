'use strict';
/* Extra preview screens, modelled on the Footprint app: boxing, meal scanner, badges,
   activity calendar, physique scanner, squad goals and calorie challenges. All values are samples. */
const fmt = value => Math.round(value).toLocaleString();

function boxing(art){
 let score=0,hits=0,time=60,active=false,ready=false,side='l',approach,miss,clock;
 function stop(){active=false;ready=false;clearTimeout(approach);clearTimeout(miss);clearInterval(clock);}
 cleanup.push(()=>{if(active){stop();$('#boxing-start').textContent='Resume round';cue('PAUSED');}});
 root.innerHTML=previewHeading('Shadowboxing')+`<div class="bx-stats"><div><span>Score</span><strong id="boxing-score">0</strong></div><div><span>Hits</span><strong id="boxing-hits">0</strong></div><div><span>Time</span><strong id="boxing-time">1:00</strong></div></div><div class="bx-ring"><span class="bx-side l">Left</span><span class="bx-side r">Right</span><div class="bx-cue" id="bx-cue">Ready?</div><button class="mitt" aria-label="Focus mitt" hidden></button><div class="bx-pop" id="bx-pop"></div></div><div class="track"><div class="fill" id="bx-clock" style="width:100%"></div></div><button class="primary full" id="boxing-start">Start 60s round</button><p class="note">Tap the mitt when it lights up. In the app your camera tracks real punches: blue mitts for your left hand, pink for your right.</p>`;
 const mitt=$('.mitt');
 function cue(text,tone){const el=$('#bx-cue');el.textContent=text;el.dataset.tone=tone||'';}
 function next(){
  if(!active)return;ready=false;side=Math.random()<.5?'l':'r';
  mitt.innerHTML=art.mitts[side];mitt.dataset.side=side;mitt.hidden=false;mitt.className='mitt';void mitt.offsetWidth;mitt.classList.add('in');cue('Get ready');
  approach=setTimeout(()=>{if(!active)return;ready=true;mitt.classList.add('lit');cue('Hit now',side);
   miss=setTimeout(()=>{if(!active)return;ready=false;mitt.className='mitt';cue('Missed','miss');approach=setTimeout(next,450);},1500);},750);
 }
 function end(){stop();mitt.hidden=true;cue('Round over','done');$('#boxing-start').textContent='Go again';time=60;}
 listen('.mitt','click',()=>{if(!active||!ready)return;clearTimeout(miss);ready=false;hits++;const gain=10+Math.min(20,hits*2);score+=gain;$('#boxing-score').textContent=score;$('#boxing-hits').textContent=hits;
  const pop=$('#bx-pop');pop.textContent='+'+gain;pop.dataset.side=side;pop.classList.remove('go');void pop.offsetWidth;pop.classList.add('go');mitt.className='mitt out';cue('Nice hit','good');approach=setTimeout(next,320);});
 listen('#boxing-start','click',()=>{
  if(active){stop();mitt.hidden=true;$('#boxing-start').textContent='Resume round';cue('Paused');return;}
  if(time===60){score=0;hits=0;$('#boxing-score').textContent='0';$('#boxing-hits').textContent='0';}
  active=true;$('#boxing-start').textContent='Pause round';
  clock=setInterval(()=>{time--;$('#boxing-time').textContent='0:'+String(time).padStart(2,'0');$('#bx-clock').style.width=time/60*100+'%';if(time<=0)end();},1000);next();});
}

function scanner(){
 const meal={name:'Salmon rice bowl',kcal:640,protein:42,carbs:58,fat:24,items:[['Grilled salmon','150 g',310],['Jasmine rice','1 cup',205],['Avocado','half',125]]};
 const plate=`<svg viewBox="0 0 200 150" aria-hidden="true"><ellipse cx="100" cy="82" rx="78" ry="56" fill="#f4f4f5"/><ellipse cx="100" cy="80" rx="62" ry="43" fill="#e4e4e7"/><path d="M62 64c10-16 34-20 46-10 8 7 6 22-6 28-16 8-36 4-42-6-2-4 0-8 2-12Z" fill="#fafafa"/><rect x="96" y="70" width="50" height="26" rx="12" transform="rotate(-14 121 83)" fill="#fb923c"/><path d="M104 80l34-9M108 88l32-8" stroke="#fdba74" stroke-width="3" stroke-linecap="round"/><path d="M70 96c0-12 9-20 20-20v40c-11 0-20-8-20-20Z" fill="#84cc16"/><path d="M76 96c0-8 6-14 14-14v28c-8 0-14-6-14-14Z" fill="#d9f99d"/><circle cx="90" cy="97" r="7" fill="#92400e"/></svg>`;
 let servings=1,timer;
 const ready=()=>{root.innerHTML=previewHeading(icon('sparkles')+'AI Nutrition Scanner')+`<p class="muted">Capture or Upload Meal Photo</p><div class="scan-view">${plate}<i class="scan-corners"></i></div><div class="actions"><button class="primary btn-ic" id="scan-snap">${icon('camera')}Snap Photo</button><button class="secondary btn-ic" id="scan-library">${icon('images-outline')}Photo Library</button></div><p class="note">A sample meal. In the app the scanner reads your own photo and estimates its calories and macros.</p>`;listen('#scan-snap','click',scan);listen('#scan-library','click',scan);};
 function scan(){root.innerHTML=previewHeading(icon('sparkles')+'AI Nutrition Scanner')+`<p class="muted">Analyzing your meal…</p><div class="scan-view is-scanning">${plate}<i class="scan-corners"></i><i class="scan-line"></i></div><div class="feedback" role="status">Finding foods and estimating portions.</div>`;clearTimeout(timer);timer=setTimeout(result,1500);}
 function result(logged){
  const x=servings;
  root.innerHTML=previewHeading(meal.name)+`<div class="macro-grid"><div class="main"><span class="caps">CALORIES</span><strong>${fmt(meal.kcal*x)}</strong><em>kcal</em></div><div><span class="caps">PROTEIN</span><strong>${fmt(meal.protein*x)}g</strong></div><div><span class="caps">CARBS</span><strong>${fmt(meal.carbs*x)}g</strong></div><div><span class="caps">FAT</span><strong>${fmt(meal.fat*x)}g</strong></div></div><div class="panel"><h3>Serving &amp; Component Breakdown</h3><ul class="list">${meal.items.map(([name,amount,kcal])=>`<li><span>${name}<small>${amount}</small></span><b>${fmt(kcal*x)} kcal</b></li>`).join('')}</ul><div class="row stepper"><span class="caps">FINE-TUNE QUANTITY</span><span><button class="secondary" id="serv-less" aria-label="Fewer servings">${icon('remove')}</button><strong id="serv">${x.toFixed(1)}</strong><span class="muted">servings</span><button class="secondary" id="serv-more" aria-label="More servings">${icon('add')}</button></span></div></div><button class="primary full btn-ic" id="scan-log" ${logged?'disabled':''}>${logged?icon('checkmark-circle')+'Logged to Daily Tracker':'Log Meal to Daily Tracker'}</button><button class="reset" id="scan-retake">Retake Photo</button>`;
  listen('#serv-less','click',()=>{servings=Math.max(.5,servings-.5);result();});listen('#serv-more','click',()=>{servings=Math.min(4,servings+.5);result();});
  listen('#scan-log','click',()=>result(true));listen('#scan-retake','click',()=>{servings=1;ready();});
 }
 cleanup.push(()=>clearTimeout(timer));ready();
}

function badges(){
 const tiers={gold:['Gold','#f59e0b','#261805'],silver:['Silver','#94a3b8','#181e29'],bronze:['Bronze','#d97706','#231205']};
 const list=[['Pathfinder','footsteps','Accumulate total lifetime steps across all recorded days.','steps',[100000,250000,1000000],'silver',8],['Trek Master','map','Complete verified outdoor walking routes.','walks',[5,20,50],'bronze',7],['Horizon Seeker','earth','Traverse overall distance across all terrains.','km',[20,100,300],'bronze',18],['Streak Titan','flame','Hit 5,000+ daily steps in continuous consecutive days.','days',[3,7,30],'silver',13],['Apex Strider','flash','Achieve a record single-day step milestone.','steps',[10000,15000,25000],'bronze',58],['Endurance Pioneer','hourglass','Longest continuous recorded walking duration.','min',[30,60,120],'bronze',50],['Calorie Crusher','bonfire','Burn active energy through workouts and daily strides.','kcal',[1000,5000,20000],'silver',50],['Tempo Master','speedometer','Complete high-cadence power walks and sustained pace sessions.','sessions',[3,10,25],'bronze',14],['Summit Peak','trophy','Climb cumulative vertical incline and elevation gain.','m',[100,500,1500],'bronze',45]];
 const count=tier=>list.filter(badge=>badge[5]===tier).length;
 let open=0;
 function coin(badge,size){const [,icon,,,,tier,percent]=badge,[,color,face]=tiers[tier],r=44,c=2*Math.PI*r;return `<svg class="coin" viewBox="0 0 100 100" style="width:${size}px;height:${size}px;color:${color}" aria-hidden="true"><circle cx="50" cy="50" r="${r}" fill="${face}" stroke="#2a2a30" stroke-width="6"/><circle cx="50" cy="50" r="${r}" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round" stroke-dasharray="${c*percent/100} ${c}" transform="rotate(-90 50 50)"/><g transform="translate(31 31) scale(.074)" fill="currentColor">${ICONS[icon]}</g></svg>`;}
 function render(){
  const badge=list[open],[title,,description,unit,targets,tier,percent]=badge,next=tier==='silver'?'Gold':'Silver';
  root.innerHTML=previewHeading('Badges')+`<div class="tier-banner"><div><strong style="color:#f59e0b">${count('gold')}</strong><span class="caps">GOLD</span></div><div><strong style="color:#94a3b8">${count('silver')}</strong><span class="caps">SILVER</span></div><div><strong style="color:#d97706">${count('bronze')}</strong><span class="caps">BRONZE</span></div></div><div class="badge-wall">${list.map((item,index)=>`<button data-badge="${index}" class="${index===open?'active':''}">${coin(item,54)}<strong>${item[0]}</strong><span>${item[6]}%</span></button>`).join('')}</div><div class="panel badge-detail" role="status">${coin(badge,58)}<div><div class="row"><h3>${title}</h3><span class="pill" style="color:${tiers[tier][1]};background:${tiers[tier][1]}22">${tiers[tier][0]}</span></div><p>${description}</p><div class="track"><div class="fill" style="width:${percent}%;background:${tiers[tier][1]}"></div></div><span class="muted">${percent}% of the way to ${next} · Bronze ${fmt(targets[0])}, Silver ${fmt(targets[1])}, Gold ${fmt(targets[2])} ${unit}</span></div></div>`;
  root.querySelectorAll('[data-badge]').forEach(button=>button.onclick=()=>{open=Number(button.dataset.badge);render();});
 }
 render();
}

function streaks(){
 // November 2026, weeks starting Monday. w = workout, g = step goal met, r = rest.
 const days='w g w r w w g  w w r g w w w  r g w w g w'.replace(/ /g,'').split('');
 const detail={w:['Workout / Active','logged workout and a walk'],g:['Goal Met','step goal reached'],r:['Rest','recovery day']};
 let today=false,picked=20;
 const steps=day=>6200+((day*2971)%5400);
 function streak(){let run=today?1:0;for(let i=days.length-1;i>=0&&days[i]!=='r';i--)run++;return run;}
 function render(){
  const all=today?[...days,'w']:days,workouts=all.filter(d=>d==='w').length,total=all.reduce((sum,_,i)=>sum+steps(i+1),0);
  const cells=Array(6).fill('<i></i>').concat(Array.from({length:30},(_,i)=>{const state=all[i]||(i===20?'t':'f');return `<button data-day="${i+1}" class="d-${state}${i+1===picked?' on':''}" ${state==='f'?'disabled':''}>${i+1}</button>`;})).join('');
  const state=all[picked-1],info=state?detail[state]:['Today','nothing logged yet'];
  root.innerHTML=previewHeading('Activity Calendar')+`<div class="cal-head"><h2>November 2026</h2><span>${icon('chevron-back')}${icon('chevron-forward')}</span></div><span class="pill btn-ic">${icon('flame')}${streak()}-day streak</span><div class="tier-banner"><div><strong>${workouts}</strong><span class="caps">LOGGED WORKOUTS</span></div><div><strong>${Math.round(total/1000)}k</strong><span class="caps">STEPS LOGGED</span></div><div><strong>${(total*0.00074).toFixed(0)} km</strong><span class="caps">WORKOUT DISTANCE</span></div></div><div class="cal"><b>M</b><b>T</b><b>W</b><b>T</b><b>F</b><b>S</b><b>S</b>${cells}</div><div class="legend"><span><i class="d-w"></i>Workout / Active</span><span><i class="d-g"></i>Goal Met</span><span><i class="d-r"></i>Rest</span></div><div class="feedback" role="status"><strong>Nov ${picked} · ${info[0]}</strong><br>${state?fmt(steps(picked))+' steps, '+info[1]:info[1]}</div><button class="primary full" id="streak-log" ${today?'disabled':''}>${today?'Today logged ✓':"Log today's workout +"}</button>`;
  root.querySelectorAll('[data-day]').forEach(button=>button.onclick=()=>{picked=Number(button.dataset.day);render();});
  listen('#streak-log','click',()=>{today=true;picked=21;render();});
 }
 render();
}

function bodyfat(){
 const height=178,weight=78.5;let neck=38,waist=86,scanned=false,timer;
 const percent=()=>Math.max(4,Math.min(45,495/(1.0324-0.19077*Math.log10(waist-neck)+0.15456*Math.log10(height))-450));
 function render(scanning){
  const bf=percent(),fat=weight*bf/100;
  root.innerHTML=previewHeading('Physique & Ab Scanner')+`<div class="panel"><h3>Biometrics &amp; Calibration</h3><label class="slider"><span><i class="caps" style="font-style:normal">NECK</i> <b>${neck} cm</b></span><input type="range" id="bf-neck" min="30" max="48" value="${neck}"></label><label class="slider"><span><i class="caps" style="font-style:normal">WAIST</i> <b>${waist} cm</b></span><input type="range" id="bf-waist" min="62" max="120" value="${waist}"></label><p class="muted">Sample profile: ${height} cm, ${weight} kg.</p></div>`+(scanning?`<div class="scan-view is-scanning small"><i class="scan-corners"></i><i class="scan-line"></i><span>Scanning Abs &amp; Definition...</span></div>`:scanned?`<div class="macro-grid"><div class="main"><span class="caps">BODY FAT PERCENTAGE</span><strong>${bf.toFixed(1)}</strong><em>%</em></div><div><span class="caps">LEAN MASS</span><strong>${(weight-fat).toFixed(1)} kg</strong></div><div><span class="caps">FAT MASS</span><strong>${fat.toFixed(1)} kg</strong></div></div><div class="method">${icon('checkmark-circle')}U.S. Navy Circumference Standard</div>`:`<div class="scan-view small"><i class="scan-corners"></i><span class="btn-ic">${icon('checkmark-circle')}Photo Ready</span></div>`)+`<button class="primary full btn-ic" id="bf-scan" ${scanning?'disabled':''}>${icon('scan-outline')}${scanned?'Scan again':'Scan physique'}</button><p class="note">A sample profile, calculated with the same U.S. Navy formula the app uses. Not a medical measurement.</p>`;
  listen('#bf-neck','input',event=>{neck=Number(event.target.value);render();});listen('#bf-waist','input',event=>{waist=Number(event.target.value);render();});
  listen('#bf-scan','click',()=>{render(true);clearTimeout(timer);timer=setTimeout(()=>{scanned=true;render();},1400);});
 }
 cleanup.push(()=>clearTimeout(timer));render();
}

function squad(){
 const goal=350000;let members=[['You',48200],['Alex',61900],['Sam',39400],['Priya',52800]],added=0;
 function render(){
  const total=members.reduce((sum,member)=>sum+member[1],0),share=Math.min(100,total/goal*100),board=[...members].sort((a,b)=>b[1]-a[1]);
  root.innerHTML=previewHeading('Community Goals')+`<p class="muted">Walk. Save. Make progress.</p><div class="row"><span class="pill btn-ic">${icon('time-outline')}Day 4 of 7</span><span class="muted">Invite code FTPR-7K2M-Q9XD</span></div><div class="panel"><div class="eyebrow">SHARED STEP TARGET</div><div class="stats"><div><span class="value">${fmt(total)}</span><br><span class="muted">steps logged</span></div><div><span class="small-value">${fmt(goal)}</span><span class="muted">goal</span></div></div><div class="track"><div class="fill" style="width:${share}%"></div></div><div class="goal-row">${icon('footsteps-outline')}<span>${fmt(Math.max(0,goal-total))} steps to go · ${Math.round(share)}% complete</span></div></div><div class="panel"><h3 class="btn-ic">${icon('trophy')}Leaderboard</h3><ul class="list">${board.map(([name,steps],index)=>`<li class="${name==='You'?'me':''}"><span><i class="rank">${index+1}</i>${name}</span><b>${fmt(steps)}</b></li>`).join('')}</ul></div><button class="primary full" id="squad-add" ${added>=3?'disabled':''}>${added>=3?'Walks added ✓':'Save a walk + 6,500 steps'}</button><button class="secondary full btn-ic" id="squad-invite">${icon('person-add-outline')}Invite friends</button><p class="note">Sample squad. In the app only shared totals and names are sent, never your GPS route.</p>`;
  listen('#squad-add','click',()=>{members=members.map(member=>member[0]==='You'?['You',member[1]+6500]:member);added++;render();});
 }
 render();
}

function challenge(){
 let days=7,plan='Cut',targetKcal=2200,logged=2050,done=false;
 function render(){
  const low=targetKcal*.9,high=targetKcal*1.1,inRange=logged>=low&&logged<=high,you=3+(done&&inRange?1:0);
  root.innerHTML=previewHeading('Calorie Challenges')+`<p class="muted">Finish each day within 10% of your shared target.</p><div class="tabs" aria-label="Plan">${['Cut','Bulk'].map(name=>`<button data-plan="${name}" class="${plan===name?'selected':''}">${name}</button>`).join('')}</div><div class="caps" style="margin:8px 0 5px">Challenge Duration</div><div class="day-chips" aria-label="Length">${[1,7,14,30].map(n=>`<button data-days="${n}" class="${days===n?'selected':''}">${n}<small>day${n>1?'s':''}</small></button>`).join('')}</div><div class="panel"><label class="slider"><span>Daily Calorie Target <b>${fmt(targetKcal)} kcal</b></span><input type="range" id="ch-target" min="1000" max="10000" step="50" value="${targetKcal}"></label><label class="slider"><span>Logged today <b>${fmt(logged)} kcal</b></span><input type="range" id="ch-logged" min="800" max="4000" step="50" value="${logged}"></label><span class="muted">A day counts when you finish within 10% of the target: ${fmt(low)} to ${fmt(high)} kcal.</span></div><div class="scoreboard"><div class="score-box you"><span>YOU</span><strong class="green">${you}</strong><span>YOUR COMPLETED DAYS</span></div><div class="score-box"><span>FRIEND</span><strong>2</strong><span>COMPLETED DAYS</span></div></div><button class="primary full" id="ch-finish" ${done?'disabled':''}>${done?(inRange?'Day won ✓':'Outside the range today'):'Finish today'}</button>`;
  root.querySelectorAll('[data-plan]').forEach(button=>button.onclick=()=>{plan=button.dataset.plan;render();});
  root.querySelectorAll('[data-days]').forEach(button=>button.onclick=()=>{days=Number(button.dataset.days);render();});
  listen('#ch-target','input',event=>{targetKcal=Number(event.target.value);done=false;render();});listen('#ch-logged','input',event=>{logged=Number(event.target.value);done=false;render();});
  listen('#ch-finish','click',()=>{done=true;render();});
 }
 render();
}

/* Log tab: a workout session with sets to tick off and a rest timer. */
function worklog(){
 const plan=[['Bench Press',[[135,10,true],[155,8,true],[165,6,false]]],['Incline Dumbbell Press',[[50,10,false],[50,10,false]]],['Triceps Pushdown',[[60,12,false],[60,12,false]]]];
 let started=false,rest=0,restSet=90,timer;
 const volume=()=>plan.reduce((sum,[,sets])=>sum+sets.filter(set=>set[2]).reduce((a,[w,r])=>a+w*r,0),0);
 const clock=seconds=>Math.floor(seconds/60)+':'+String(seconds%60).padStart(2,'0');
 function tick(){clearInterval(timer);if(rest<=0)return;timer=setInterval(()=>{rest--;if(rest<=0){rest=0;clearInterval(timer);render();return;}const el=$('#rest-clock');if(el)el.textContent=clock(rest);},1000);}
 cleanup.push(()=>clearInterval(timer));
 function render(){
  if(!started){root.innerHTML=previewHeading('Fitness Log')+`<div class="panel"><div class="eyebrow">YOUR NEXT SESSION</div><h2 style="margin-top:8px">Push</h2><p class="muted">${plan.map(([name])=>name).join(' · ')}</p><button class="primary full btn-ic" id="log-start">${icon('play')}Start workout</button></div><div class="panel"><h3>Workout days</h3><ul class="list">${[['Push','Chest, shoulders, triceps'],['Pull','Back and biceps'],['Legs','Quads, hamstrings, calves'],['Upper','Full upper body']].map(([day,note],i)=>`<li><span>${day}<small>${note}</small></span>${i===0?'<b class="green">Next</b>':icon('chevron-forward')}</li>`).join('')}</ul></div><p class="note">Sample routine. Build your own workout days in the app.</p>`;listen('#log-start','click',()=>{started=true;render();});return;}
  root.innerHTML=previewHeading('Push')+`<div class="row"><span class="pill btn-ic">${icon('barbell-outline')}${fmt(volume())} lbs lifted</span>${rest?`<span class="pill btn-ic rest">${icon('timer-outline')}<b id="rest-clock">${clock(rest)}</b></span>`:`<span class="muted btn-ic">${icon('timer-outline')}Rest Interval ${clock(restSet)}</span>`}</div>`+(rest?`<div class="actions rest-actions"><button class="secondary" id="rest-less">−15s</button><button class="secondary" id="rest-more">+15s</button><button class="secondary" id="rest-skip">Skip</button></div>`:'')+plan.map(([name,sets],e)=>`<div class="panel sets"><h3>${name}</h3><div class="set head"><span>SET</span><span>LBS</span><span>REPS</span><span></span></div>${sets.map(([w,r,done],i)=>`<div class="set${done?' done':''}"><span>${i+1}</span><span>${w}</span><span>${r}</span><button data-set="${e}-${i}" aria-label="Complete set">${icon(done?'checkmark-circle':'ellipse-outline')}</button></div>`).join('')}<button class="reset btn-ic" data-add="${e}">${icon('add')}Add Set</button></div>`).join('');
  root.querySelectorAll('[data-set]').forEach(button=>button.onclick=()=>{const [e,i]=button.dataset.set.split('-').map(Number),set=plan[e][1][i];set[2]=!set[2];rest=set[2]?restSet:rest;render();tick();});
  root.querySelectorAll('[data-add]').forEach(button=>button.onclick=()=>{const sets=plan[Number(button.dataset.add)][1],last=sets[sets.length-1];sets.push([last[0],last[1],false]);render();});
  listen('#rest-less','click',()=>{rest=Math.max(0,rest-15);render();tick();});listen('#rest-more','click',()=>{rest+=15;render();tick();});listen('#rest-skip','click',()=>{rest=0;clearInterval(timer);render();});
 }
 render();
}

/* Calorie Tracker tab: the day's calories, macros, water and quick-add foods. */
function tracker(){
 const goal=2450,macroGoal={protein:180,carbs:260,fat:75};
 let eaten=1220,macros={protein:86,carbs:128,fat:38},water=3;
 const foods=[['2 eggs',140,[12,1,10]],['Sourdough toast with butter',190,[5,27,7]],['Iced latte',130,[7,12,6]],['Greek yogurt and berries',160,[15,18,3]]];
 const added=new Set();
 function render(){
  const left=Math.max(0,goal-eaten),r=52,c=2*Math.PI*r,share=Math.min(1,eaten/goal);
  root.innerHTML=previewHeading('Calorie Tracker')+`<div class="panel ring-card"><svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="60" r="${r}" fill="none" stroke="#29292e" stroke-width="11"/><circle cx="60" cy="60" r="${r}" fill="none" stroke="#a3e635" stroke-width="11" stroke-linecap="round" stroke-dasharray="${c*share} ${c}" transform="rotate(-90 60 60)"/></svg><div class="ring-mid"><strong>${fmt(left)}</strong><span>kcal left</span></div><div class="ring-side"><div><span class="caps">CALORIES</span><b>${fmt(eaten)}</b></div><div><span class="caps">TARGET</span><b>${fmt(goal)}</b></div></div></div><div class="macro-bars">${Object.keys(macros).map(key=>`<div><span class="caps">${key.toUpperCase()}</span><b>${macros[key]}g</b><div class="track"><div class="fill" style="width:${Math.min(100,macros[key]/macroGoal[key]*100)}%"></div></div></div>`).join('')}</div><div class="panel"><div class="row"><h3 class="btn-ic">${icon('water')}Daily Water</h3><button class="secondary btn-ic" id="water-add">${icon('add')}Log Water</button></div><div class="glasses" aria-label="${water} of 8 glasses">${Array.from({length:8},(_,i)=>`<i class="${i<water?'on':''}"></i>`).join('')}</div></div><div class="panel"><h3>Your Essentials</h3><ul class="list">${foods.map(([name,kcal],i)=>`<li><span>${name}<small>${kcal} kcal</small></span><button class="secondary add" data-food="${i}" ${added.has(i)?'disabled':''} aria-label="Log ${name}">${icon(added.has(i)?'checkmark':'add')}</button></li>`).join('')}</ul></div>`;
  listen('#water-add','click',()=>{water=Math.min(8,water+1);render();});
  root.querySelectorAll('[data-food]').forEach(button=>button.onclick=()=>{const i=Number(button.dataset.food),[,kcal,[p,cb,f]]=foods[i];added.add(i);eaten+=kcal;macros={protein:macros.protein+p,carbs:macros.carbs+cb,fat:macros.fat+f};render();});
 }
 render();
}

/* Track tab: pick a target distance, see a suggested route on the map, then walk it. */
const TRACK_MAP=`<rect width="300" height="230" fill="#141417"/><path d="M-10 168C40 150 70 190 120 176s70-44 120-34 60 30 80 26v80H-10Z" fill="#12202b"/><path d="M186 18h88v70h-88Z" fill="#16241a"/><path d="M18 96h64v54H18Z" fill="#16241a"/><g stroke="#26262c" stroke-width="7" fill="none" stroke-linecap="round"><path d="M-10 52h320M-10 122h320M52-10v250M130-10v250M212-10v250M-10 12l150 216M300 20 150 240"/></g>`;
const TRACK_ROUTES={2:['M52 198V122h78V52h82',2,1.2],5:['M52 198V122h78V52h82v70h60',5,3.4],10:['M52 198V52h78v70h82V18h62v104h-62v60',10,6.8]};
function track(){
 let target=5,pref='Parks & Trails',state='plan',progress=0,raf,startTime;
 const prefs=[['Parks & Trails','leaf-outline'],['Less Traffic / Quiet','navigate-outline'],['Avoid Traffic Lights','flash-outline']];
 cleanup.push(()=>cancelAnimationFrame(raf));
 function stats(km){const minutes=km*11.5;return `<div class="tier-banner four"><div><strong>${km.toFixed(2)}</strong><span class="caps">KM</span></div><div><strong>${Math.floor(minutes)}:${String(Math.round(minutes%1*60)).padStart(2,'0')}</strong><span class="caps">${state==='plan'?'EST. TIME':'DURATION'}</span></div><div><strong>${fmt(km*1312)}</strong><span class="caps">${state==='plan'?'EST. STEPS':'STEPS'}</span></div><div><strong>${fmt(km*61)}</strong><span class="caps">CALORIES</span></div></div>`;}
 function render(){
  const [d,km,climb]=TRACK_ROUTES[target];
  root.innerHTML=previewHeading(state==='done'?'Walk Complete!':'Track')+`<div class="map"><svg viewBox="0 0 300 230" preserveAspectRatio="xMidYMid slice" aria-label="Map with a ${km} kilometre suggested route">${TRACK_MAP}<path id="route" d="${d}" fill="none" stroke="#a3e635" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" ${state==='plan'?'stroke-dasharray="1 9"':''}/><path id="walked" d="${d}" fill="none" stroke="#a3e635" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" style="display:${state==='plan'?'none':'block'}"/><circle id="dot" cx="52" cy="198" r="7" fill="#fafafa" stroke="#09090b" stroke-width="3"/></svg><span class="map-chip btn-ic">${icon('location')}Current Location (Start)</span></div><div id="track-stats">${stats(state==='plan'?km:km*progress)}</div>`+(state==='plan'?`<div class="caps" style="margin:8px 0 5px">TARGET DISTANCE</div><div class="day-chips three">${[2,5,10].map(n=>`<button data-km="${n}" class="${target===n?'selected':''}">${n}<small>km</small></button>`).join('')}</div><div class="pref-chips">${prefs.map(([name,ic])=>`<button data-pref="${name}" class="${pref===name?'selected':''}">${icon(ic)}${name}</button>`).join('')}</div><div class="goal-row">${icon('trending-up-outline')}<span>Elevation ${Math.round(climb*9)} m · Explore Suggested Routes</span></div><button class="primary full btn-ic" id="track-start">${icon('navigate')}START</button>`:state==='walk'?`<div class="feedback" role="status">Turn-by-Turn Directions · follow the green route</div><button class="secondary full btn-ic" id="track-stop">${icon('stop')}Finish walk</button>`:`<div class="feedback" role="status"><strong>Great work on your route.</strong><br>Goal progress added.</div><button class="primary full" id="track-again">Plan another route</button>`);
  const route=$('#walked'),length=route.getTotalLength();
  const place=()=>{route.style.strokeDasharray=`${length*progress} ${length}`;const point=route.getPointAtLength(length*progress);$('#dot').setAttribute('cx',point.x);$('#dot').setAttribute('cy',point.y);};
  if(state!=='plan')place();
  root.querySelectorAll('[data-km]').forEach(button=>button.onclick=()=>{target=Number(button.dataset.km);render();});
  root.querySelectorAll('[data-pref]').forEach(button=>button.onclick=()=>{pref=button.dataset.pref;render();});
  listen('#track-start','click',()=>{state='walk';progress=0;render();startTime=undefined;const duration=4200+target*500;
   const frame=now=>{if(startTime===undefined)startTime=now;progress=Math.min(1,(now-startTime)/duration);const live=$('#walked');if(!live)return;const total=live.getTotalLength();live.style.strokeDasharray=`${total*progress} ${total}`;const point=live.getPointAtLength(total*progress);$('#dot').setAttribute('cx',point.x);$('#dot').setAttribute('cy',point.y);$('#track-stats').innerHTML=stats(TRACK_ROUTES[target][1]*progress);if(progress<1)raf=requestAnimationFrame(frame);else{state='done';render();}};raf=requestAnimationFrame(frame);});
  listen('#track-stop','click',()=>{cancelAnimationFrame(raf);state='done';render();});
  listen('#track-again','click',()=>{state='plan';progress=0;render();});
 }
 render();
}
