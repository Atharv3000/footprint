'use strict';
/* Winding trails of footprints across the neon banner. Each step blurs in dark, then lightens and fades. */
(() => {
  const layer = document.querySelector('.hero-trail');
  const banner = layer?.closest('.opening');
  if (!layer || !banner) return;
  banner.prepend(layer);   // cover the whole banner, behind the header and headline
  const src = layer.dataset.foot;
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const random = (min, max) => min + Math.random() * (max - min);
  const LIFE = 6;
  let timer, visible = true;

  // Text and buttons: trails lean away from these, and any step that does cross them is drawn faintly.
  function quietZones(pad) {
    const base = banner.getBoundingClientRect();
    return [...banner.querySelectorAll('.intro-copy h1, .intro-sub, .brand, .store-buttons')].map(element => {
      const box = element.getBoundingClientRect();
      return {left:box.left - base.left - pad, right:box.right - base.left + pad, top:box.top - base.top - pad, bottom:box.bottom - base.top + pad};
    });
  }

  // One candidate path: enters from an edge and meanders in S-curves until it leaves the banner.
  function plan(width, height, size, zones) {
    const stride = size * 2.4, gap = size * 0.8, margin = size * 3;
    const side = Math.floor(random(0, 4));
    let x, y, base;
    if (side === 0) { x = -margin; y = random(0.1, 0.95) * height; base = random(-0.3, 0.3); }
    else if (side === 1) { x = width + margin; y = random(0.1, 0.95) * height; base = Math.PI + random(-0.3, 0.3); }
    else if (side === 2) { x = random(0.05, 0.95) * width; y = height + margin; base = -Math.PI / 2 + random(-0.5, 0.5); }
    else { x = random(0.05, 0.95) * width; y = -margin; base = Math.PI / 2 + random(-0.5, 0.5); }
    const swing = random(0.55, 0.85), rate = random(0.16, 0.24), phase = random(0, Math.PI * 2), drift = random(-0.008, 0.008);
    const wobble = 0, wobbleRate = 0, wobblePhase = 0;
    const steps = [];
    let blocked = 0;
    for (let index = 0; index < 160; index++) {
      const heading = base + drift * index + swing * Math.sin(phase + index * rate) + wobble * Math.sin(wobblePhase + index * wobbleRate);
      x += Math.cos(heading) * stride; y += Math.sin(heading) * stride;
      if (index > 4 && (x < -margin || x > width + margin || y < -margin || y > height + margin)) break;
      const right = index % 2 === 1, offset = right ? gap : -gap;
      const fx = x - Math.sin(heading) * offset, fy = y + Math.cos(heading) * offset;
      const hidden = zones.some(zone => fx > zone.left && fx < zone.right && fy > zone.top && fy < zone.bottom);
      const inside = fx > 0 && fx < width && fy > 0 && fy < height;
      if (hidden && inside) blocked++;
      steps.push({fx, fy, heading, right, hidden, index, inside});
    }
    const shown = steps.filter(step => step.inside).length;
    return {steps, blocked, shown};
  }

  function walk(animated) {
    const width = banner.clientWidth, height = banner.clientHeight;
    const size = width < 720 ? 16 : 22;   // every trail uses the same foot size   // foot width in px
    const zones = quietZones(size);
    // Try several routes and keep the one that stays clearest of the text.
    let best;
    for (let attempt = 0; attempt < 5; attempt++) {
      const route = plan(width, height, size, zones);
      if (route.shown < 10) continue;
      if (!best || route.blocked < best.blocked) best = route;
      if (best.blocked === 0) break;
    }
    if (!best) return 1;
    const pace = 0.36;   // seconds between one step and the next
    let quiet = false;
    const trail = document.createElement('div');
    for (const step of best.steps) {
      const foot = document.createElement('img');
      quiet = step.hidden;
      foot.src = src; foot.alt = '';
      foot.style.width = size + 'px';
      foot.style.transform = `translate(${step.fx}px,${step.fy}px) translate(-50%,-50%) rotate(${step.heading + Math.PI / 2}rad) scaleX(${step.right ? -1 : 1})`;
      if (quiet) foot.className = 'is-quiet';
      foot.style.setProperty('--delay', (animated ? step.index * pace : 0) + 's');
      trail.append(foot);
    }
    layer.append(trail);
    if (animated) setTimeout(() => trail.remove(), (best.steps.length * pace + LIFE) * 1000 + 200);
    return best.steps.length * pace;
  }

  // One trail at a time: the next walker sets off only after the last one has finished crossing.
  function schedule() {
    clearTimeout(timer);
    if (reducedMotion.matches || !visible || document.hidden) return;
    const seconds = walk(true);
    timer = setTimeout(schedule, (seconds + 0.6) * 1000);
  }
  function start() {
    clearTimeout(timer);
    layer.replaceChildren();
    layer.classList.toggle('is-static', reducedMotion.matches);
    if (reducedMotion.matches) { walk(false); return; }
    schedule();
  }
  reducedMotion.addEventListener('change', start);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && !timer) schedule(); });
  if ('IntersectionObserver' in window) new IntersectionObserver(entries => { const was = visible; visible = entries[0].isIntersecting; if (visible && !was) schedule(); else if (!visible) { clearTimeout(timer); timer = undefined; } }).observe(banner);
  start();
})();
