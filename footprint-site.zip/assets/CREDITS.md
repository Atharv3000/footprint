# Image credits

All images on the landing page are Footprint's own (logo, footprint marks, app screenshots and preview art).

Icons in the phone previews and feature grid are Ionicons (https://ionic.io/ionicons), MIT licence, the same set the Footprint app uses.
